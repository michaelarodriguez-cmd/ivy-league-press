# Ivy League Press — Website prototype

Open `index.html` in any browser to preview. The site is responsive and uses plain HTML, CSS and JavaScript; no build tools required.

## Recommended publishing path
1. Purchase a domain only after checking trademark and naming risks.
2. Create a GitHub repository with these files.
3. Import the repository into Vercel and deploy as a static site.
4. Replace `hello@example.com` with a real newsroom email address.
5. Add a CMS (such as Sanity) when publishing regularly; this prototype does not yet have an editorial dashboard.
6. Establish secure tip intake before soliciting confidential information.
7. Replace every demonstration story with fact-checked reporting, including bylines, dates, sources, corrections and legal review where appropriate.

The site is not currently deployed. No domain or Instagram username has been registered or verified.
